Olympiad Problem Lab public frontend update

Implemented:
- Review mistakes page showing checked incorrect questions.
- Saved questions/bookmarks stored in local browser storage.
- Problem Library search and progress filters (incorrect, unattempted, correct, saved).
- Single-correct MCQ, multiple-correct MCQ, and integer answer support in practice and timed tests.
- Multiple-correct grading requires the exact set of correct options.
- Existing local progress structure is preserved and bookmarks are added compatibly.

Important:
- This is a frontend file only. It does not update GitHub Pages automatically.
- The public frontend still uses localStorage for student progress; it is device/browser-specific.
- Mock-format records in Supabase are not yet loaded into the public test setup. The mock test builder remains the existing local full/section practice builder.
- Supabase public questions with MULTIPLE_CORRECT will be loaded if the database migration is applied and those records are published.
